// button click handler
const play = (event) => {

//apply event to generate new game state


// game state renderer renders the generated game state

// renders text on button clicked with X or O

// disable the button clicked

// update panel values such as Turn Played By and Moves Left

// reset panel values to default values

// implement logic to get the winner

// announce winner
}

// REPLAY-MODE :: replay-game-button-clicked->fetches events recorded->apply event->generates new game state->render game state


// reset game to start a new



// bind events to clickable buttons
function enableButtons() {}

module.exports = play;
