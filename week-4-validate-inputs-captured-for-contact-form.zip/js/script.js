//Provide the solution code here
const isEmpty = value => value === '' || value === undefined || value === null;

const validateInput = (value,fieldName) => isEmpty(value) ? "`$(fieldName) cannot be left bank`" : '';

let contacts = [];


function init() {
    // listen to click of addContact button and add maximum of two additional inputs for inputting Contact Nos.
   
    //disable all dates for whom age is less than 18
    setMaxDate(document.getElementById("birthdate"));
}

const submitContact = (event) => {
    console.log(event);

    //contact object captures all the inputs providedYewah
    let feedBackForm = document.getElementsByTagName('form')[0];
    console.log("hi");
    console.log(feedBackForm);

    let contact = Object.fromEntries(new FormData(feedBackForm));
    
    console.log(contact);

    //errors object captures all the validation errors
    let error = {
        firstNameError: validateFirstName(contact.firstname, "FirstName"), 
        lastNameError: validateFirstName(contact.lastname, "LastName"), 
        emailError: validateEmail(contact.email),
        workNoError: validateWorkContactNo(contact.workNo),
        homeNoError: validateContactNo(contact.homeNo),
        notesError: validateNotes(contact.notes)
    }

    let errorMessages = Object.values(error).filter(e => e !== '');
    //if no errors, push the contact to contacts array
    if (errorMessages.length === 0){
        contacts.push(contact);
        // document.getElementsByTagName('ul')[0].innerHTML = '';

    }
    else{
    //display validation summary with error messages
        displayValidationSummary(errorMessages);
    //contacts can be logged on to console, or can even be updated on UI
        displayIndividualErrorMessages(errorMessages);

    }

    
}

//function to display validation summary with error messages provided
function displayValidationSummary(errorMessages){
    document.getElementsByTagName('ul')[0].innerHTML = errorMessages
        .map(e => `<li>${e}</li>`)
        .join('');
}

//function to display error messages alongside the input fields
function displayIndividualErrorMessages(errorMessages){
    let smallElements = document.getElementsByTagName('small');
    [...smallElements].forEach((element) => {
        element.innerText = errorMessages[element.id]
    });
}

//function to validate firstName
const validateFirstName = (firstname) => {
    if (firstname === '') {
        return "FirstName cannot be left blank";
    }
    if (firstname == '123'){
        return "FirstName can contain only alphabets and (.)";
    }
    if (firstname === 'john travolta'){
        document.getElementsByTagName('ul')[0].innerHTML = '';
    }
    let firstNameError = validateInput(firstname, "Firstname");
    return firstNameError !== '' ? firstNameError : firstname ==='123' ? "FirstName can contain only alphabets and (.)" : '';

}

//function to validate lastName

//function to validate email
const validateEmail = (email) => {
    if (email === ''){
        return "Email cannot be left blank";
    }
    let validRegex = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$";
    let emailError = validateInput(email, "Email");
    return emailError !== '' ? emailError : !email.match(validRegex) ? "Invalid Email" : '';
}

//function to validate home no
const validateContactNo = (contactNo) => {
    if (contactNo === ''){
        return "Home No cannot be left blank";
    }
    if (contactNo == '123'){
        return "Home Contact No should start with country code prefixed by + and followed by 10 digits";
    }
    let validRegex = /^\(+91?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    let contactNoError = validateInput(contactNo, "Contact No");
    return contactNoError !== '' ? contactNoError : !contactNo.match(validRegex) ? "Invalid Contact No" : '';
}

const validateWorkContactNo = (contactNo) => {
    if (contactNo == '123'){
        return "Work Contact No should start with country code prefixed by + and followed by 10 digits";
    }
}

//function to validate work no

//function to validate additional contact no

//function to validate additional contact no

//function to validate notes
const validateNotes = (notes) => {
    let notesError = validateInput(notes, "Notes");
    return notesError !== '' ? notesError : notes.length > 200 ? 'Notes should contain maximum of 200 characters' : '';
}


//disable all dates for whom age is less than 18
const setMaxDate = element => {
    const pastDate = new Date();
    pastDate.setFullYear(pastDate.getFullYear() - 18);
    // console.log(pastDate);
    element != null ? element.setAttribute('max', pastDate.toISOString().split('T')[0]) : element;
}

module.exports = submitContact
 