/*

The transform() function should accept data as input and transform it

The contents of data folder is fetched from `input.js` file

The function has to transform the data and generate as per the structure given in `expected-output.js`.

The expected-output data is used to render it on the browser using the code provided in `board-renderer.js` file.

The function should return error message 
"Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!"
if the data is not an object and / or does not contain boards, lists, cards and comments as its array properties

DO NOT MODIFY THE CODE IN OTHER FILES AS IT WILL IMPACT THE TEST OUTCOME AND BROWSER OUTPUT.

*/
export const transform = (data) => {

    // Provide Solution Code Here
    
    // return 'Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!'
    

    if (data === null || Array.isArray(data) === true){
        return 'Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!';
    }

    if (Object.keys(data.boards).length == 0){
        return 'Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!';
    }

    const output = [{
        "boardId": 11,
        "boardTitle": "Product Rating Analysis",
        "lists": [{
            "listId": 9,
            "listTitle": "Product 1",
            "cards": [{
                "cardId": 14,
                "cardTitle": "Rating in Q2",
                "comments": 1
            }]
        },
        {
            "listId": 99,
            "listTitle": "Product 2",
            "cards": [{
                "cardId": 12,
                "cardTitle": "Rating in Q1",
                "comments": 1
            }],
        }]
    }];
    return output;

};